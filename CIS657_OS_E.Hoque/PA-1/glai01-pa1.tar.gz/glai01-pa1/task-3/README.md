# Readme for Task-3

## How to test your solution?

First, check if your `cpuinfo.txt` follows the template mentioned in the
description. 

`cat /proc/cpuinfo` prints out all CPU information of the host. Use this
information to check if your `cpuinfo.txt` includes the appropriate
data.

## Clean command

    $ make clean
