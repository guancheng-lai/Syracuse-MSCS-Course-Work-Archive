#!/bin/bash

# number of processor
array_processor=(`cat /proc/cpuinfo | grep "processor"`)
num_processor=${#array_processor[@]}
echo $((num_processor/3)) > cpuinfo.txt

# show core id
#cat /proc/cpuinfo | grep "core id" > coreid.txt
cat /proc/cpuinfo | awk '/core id/ {print $4}' >> cpuinfo.txt

# show cache size
cat /proc/cpuinfo | awk '/cache size/ {print $4}' >> cpuinfo.txt
