#!/bin/bash

workDir="$PWD"
path_archive=$workDir"/allcfiles.tar"

function findC {
	for fd in */; do
		tar --append --file=$path_archive `find *.c`
		if [ -d "$fd" ]; then
			cd "$fd"
			findC
			cd ..
		fi
	done
}

findC
