# Readme for Task-2

## How to test your solution?

Use `tar tvf` on your archive to check if it includes all .c files
in the current directory and its subdirectories.


## Clean command

    $ make clean
