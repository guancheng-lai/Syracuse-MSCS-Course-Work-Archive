#!/bin/bash

tar -xvf input.tar.gz
mkdir TXT JPG ZIP
cd input
mv `find . -name "*.txt"` ../TXT
mv `find . -name "*.jpg"` ../JPG
mv * ../ZIP
cd ..
tar -czvf rest_zipped.tar.gz ./ZIP/*
