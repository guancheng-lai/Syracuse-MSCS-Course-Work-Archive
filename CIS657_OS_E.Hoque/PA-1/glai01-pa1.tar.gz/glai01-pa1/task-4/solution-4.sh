#!/bin/bash

mapfile -t pid_array < <(ps -u $USER | awk '/infloop$/ {print $1}')
for (( i=0; i<${#pid_array[@]}; i++ ));
do
#	echo Killing ${pid_array[i]};
	kill -9 ${pid_array[i]}
	echo Killed ${pid_array[i]};
done
