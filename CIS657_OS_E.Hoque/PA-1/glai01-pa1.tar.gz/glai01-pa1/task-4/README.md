# Readme for Task-4

## How to test your solution?

Step 1. Run `spawner.sh` and 
Step 2. Run your `solution-4.sh`.
Step 3. Now check if it worked or not by typing: 

    $ make test

If it passes the test, this command should only print 
`No infloop is alive`; otherwise it prints information about the alive
`infloop` processes.

## Clean command

    $ make clean
