#!/bin/bash

rm -r smart OS sample_data result.txt sample_data.tar

wget $1
tar -xvpf sample_data.tar
mkdir smart OS
DIR=./sample_data/*


for file in $DIR
do
	count=$(grep -o 'smart' $file | wc -l)
	if [[ $count -gt 0 ]]
	then
		cp $file smart
	fi
	echo "${file##*/}" smart $count >> result.txt
done

for file in $DIR
do
	count=$(grep -o 'operating system' $file | wc -l)
	if [[ $count -gt 0 ]]
        then
                cp $file OS
        fi
	echo "${file##*/}" operating system $count >> result.txt
done

