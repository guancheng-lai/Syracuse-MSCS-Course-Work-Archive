#!/bin/bash
mkdir Assignment-1
cd Assignment-1
for i in `seq 1 10`;
do
	mkdir Query-$i
	touch Query-$i/response-$i.sh
done
