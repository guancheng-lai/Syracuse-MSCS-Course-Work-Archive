#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

void errorExit() {
	fprintf(stderr, "An error has occured\n");
	exit(1);
}

int main()
{
	char *s;
	s = malloc(1024 * sizeof(char));
	if (s == NULL) errorExit();

	size_t len = strlen(s);
	char delim[] = " \t\n";

	while (getline(&s, &len, stdin) != -1) {
		if (strlen(s) == 5 && strncmp(s, "exit", 4) == 0) exit(0);
		len = strlen(s);

		char * tok = strtok(s, delim);
		while (tok != NULL) {
			printf("%s\n", tok);
			tok = strtok(NULL, delim);
		}
	}

	free(s);
	return 0;
}
