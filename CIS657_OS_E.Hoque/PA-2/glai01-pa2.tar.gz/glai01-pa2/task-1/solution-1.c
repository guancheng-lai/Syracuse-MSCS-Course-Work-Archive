#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>
#include <ctype.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

void errorExit() {
	fprintf(stderr, "An error has occured\n");
	exit(1);
}

int main(int argc, char *argv[]) {
	if (argc < 2) {
		errorExit();
	}

	FILE * fp;
	fp = fopen(argv[1], "r");
	if (fp == NULL) errorExit();

	char line[1024];
	while ( fgets(line, sizeof(line), fp) ) {
		//printf("%d: %s", i, line);
		char * commands[4];
	        int idx;
        	for (idx = 0; idx < 3; idx++) {
                	commands[idx] = (char *)malloc(1024 * sizeof(char));
        	}

		char * patch;
		patch = strtok(line, " ");
		if (patch == NULL) errorExit();
		strcat(commands[0], patch);

 		patch = strtok(NULL, " ");
                if (patch == NULL) errorExit();
		strcat(commands[1], patch);

		patch = strtok(NULL, " ");
		if (patch == NULL) errorExit();
                strncat(commands[2], patch, strlen(patch)-1);

		//printf("Line %d: %s %s %s\n", i++, commands[0], commands[1], commands[2]);

		int rc = fork();
		if (rc < 0) { 		// Error
			errorExit();
		}
		else if (rc == 0) { // Child 
			if (strcmp(commands[0], "cp") == 0) {
				execl("/bin/cp", commands[0], commands[1], commands[2], NULL);
				//execv("/bin/cp", commands);
			}
			else if (strcmp(commands[0], "mv") == 0) {
				execl("/bin/mv", commands[0], commands[1], commands[2], NULL);
				//execv("/bin/mv", commands);
			}
			else {
				errorExit();
			}
		}
		else { 				// Parent
			wait(NULL);
		}
	}

	fclose(fp);
}
