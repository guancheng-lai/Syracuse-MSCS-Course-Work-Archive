#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>
#include <ctype.h>
#include <string.h>


void errorExit() {
	fprintf(stderr, "An error has occured\n");
	exit(1);
}

int main(int argc, char *argv[]) {
	if (argc < 3) {
	        errorExit();
	}

	FILE * fp_input, * fp_output;
	fp_input = fopen(argv[1], "r");
	fp_output = fopen(argv[2], "a");
	if (fp_input == NULL || fp_output == NULL) errorExit();

	char hex[1024];
	char bin[1024];

	int rc = fscanf(fp_input,"%s", hex);
	while (rc > 0) {
		int i;
		for (i = 0; hex[i] != '\0'; i++) {
			switch (hex[i]) {
				case '0':
					strcat(bin, "0000");
					break;
				case '1':
					strcat(bin, "0001");
					break;
				case '2':
					strcat(bin, "0010");
					break;
				case '3':
					strcat(bin, "0011");
					break;
				case '4':
					strcat(bin, "0100");
					break;
				case '5':
					strcat(bin, "0101");
					break;
				case '6':
					strcat(bin, "0110");
					break;
				case '7':
					strcat(bin, "0111");
					break;
				case '8':
					strcat(bin, "1000");
					break;
				case '9':
					strcat(bin, "1001");
					break;
				case 'a':
					strcat(bin, "1010");
					break;
				case 'b':
					strcat(bin, "1011");
					break;
				case 'c':
					strcat(bin, "1100");
					break;
				case 'd':
					strcat(bin, "1101");
					break;
				case 'e':
					strcat(bin, "1110");
					break;
				case 'f':
					strcat(bin, "1111");
					break;
				}
//			strcat(bin, " ");
		}
		fprintf(fp_output, "%s\n", bin);
		memset(bin, 0, strlen(bin));
		rc = fscanf(fp_input, "%s", hex);
	}

	fclose(fp_input);
	fclose(fp_output);
}
