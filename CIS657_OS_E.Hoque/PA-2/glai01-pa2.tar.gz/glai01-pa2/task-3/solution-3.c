#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>
#include <ctype.h>
#include <string.h>


void errorExit() {
	fprintf(stderr, "An error has occured\n");
	exit(1);
}

int main(int argc, char *argv[]) {
	if (argc < 3) {
	        errorExit();
	}

	FILE * fp_input, * fp_output;
	fp_input = fopen(argv[1], "r");
	fp_output = fopen(argv[2], "a");
	if (fp_input == NULL || fp_output == NULL) errorExit();

	char bin[1024];
	char hex[1024];
	memset(bin, 0, 1023);
	memset(hex, 0, 1023);

	int rc = fscanf(fp_input,"%s", bin);
	while (rc > 0) {
		if (strcmp(bin, "") == 0) {
			//printf("Empty String\n");
			errorExit();
		}

		if (strlen(bin) % 4 != 0) {
			//printf("strlen(%s) = %zu\n", bin, strlen(bin));
			errorExit();
		}

		//printf("Input: %s, Output: %s\n", bin, hex);

		int i;
		for (i = 0; i < strlen(bin); i += 4) {
			char tmp[5];
			strncpy(tmp, bin+i, 4);

			if (strncmp(tmp, "0000", 4) == 0) {
				strcat(hex, "0");
			}
			else if (strncmp(tmp, "0001", 4) == 0){
				strcat(hex, "1");
			}
			else if (strncmp(tmp, "0010", 4) == 0){
				strcat(hex, "2");
			}
			else if (strncmp(tmp, "0011", 4) == 0){
				strcat(hex, "3");
			}
			else if (strncmp(tmp, "0100", 4) == 0){
				strcat(hex, "4");
			}
			else if (strncmp(tmp, "0101", 4) == 0){
				strcat(hex, "5");
			}
			else if (strncmp(tmp, "0110", 4) == 0){
				strcat(hex, "6");
			}
			else if (strncmp(tmp, "0111", 4) == 0){
				strcat(hex, "7");
			}
			else if (strncmp(tmp, "1000", 4) == 0){
				strcat(hex, "8");
			}
			else if (strncmp(tmp, "1001", 4) == 0){
				strcat(hex, "9");
			}
			else if (strncmp(tmp, "1010", 4) == 0){
				strcat(hex, "a");
			}
			else if (strncmp(tmp, "1011", 4) == 0){
				strcat(hex, "b");
			}
			else if (strncmp(tmp, "1100", 4) == 0){
				strcat(hex, "c");
			}
			else if (strncmp(tmp, "1101", 4) == 0){
				strcat(hex, "d");
			}
			else if (strncmp(tmp, "1110", 4) == 0){
				strcat(hex, "e");
			}
			else if (strncmp(tmp, "1111", 4) == 0){
				strcat(hex, "f");
			}
			else {
				errorExit();
			}
		}

		//printf("Output: %s\n", hex);
		fprintf(fp_output, "%s\n", hex);
		memset(hex, 0, strlen(hex));
		rc = fscanf(fp_input, "%s", bin);
	}

	fclose(fp_input);
	fclose(fp_output);
}
