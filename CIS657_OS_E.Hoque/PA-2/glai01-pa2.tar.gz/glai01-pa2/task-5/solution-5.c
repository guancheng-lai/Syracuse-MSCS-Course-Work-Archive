#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>
#include <ctype.h>
#include <sys/stat.h>
#include "sort.h"

int myComp (const void * a, const void * b) {
	const rec_t * pa = (const rec_t *) a;
	const rec_t * pb = (const rec_t *) b;
	return ((*pa).key > (*pb).key) - ((*pa).key < (*pb).key);
}

void errorExit() {
	fprintf(stderr, "An error has occured\n");
	exit(1);
}

void argcErrorExit() {
        fprintf(stderr, "usage: ./dump input_binary_filename output_binary_filename");
        exit(1);
}

void fileErrorExit(char * filename) {
        fprintf(stderr, "Error: Cannot open file %s\n", filename);
        exit(1);
}

int main(int argc, char *argv[]) {
	char * inFile, * outFile;
	if (argc == 3) {
		inFile = strdup(argv[1]);
		outFile = strdup(argv[2]);
	}
	else {
		errorExit();
	}

	int fd1 = open(inFile, O_RDONLY);
	if (fd1 < 0) fileErrorExit(inFile);

	int fd2 = open(outFile, O_WRONLY|O_CREAT|O_TRUNC, S_IRWXU);
	if (fd2 < 0) fileErrorExit(outFile);

	struct stat st;
	stat(argv[1], &st);
	int numRecords = (st.st_size)/(sizeof(rec_t));
	//printf("num = %d\n", numRecords);
	rec_t * arr = malloc(numRecords * sizeof(rec_t));

	int idx;
	for (idx = 0; idx < numRecords; ++idx){
		int rc;
		rc = read(fd1, arr + idx, sizeof(rec_t));
		if (rc == 0) // 0 indicates EOF
			break;
		if (rc < 0) {
			errorExit();
		}

		//printf("key: %10u ", (arr + idx)->key);
		//printf(" record:");
		//int j;
		//for (j = 0; j < NUMRECS; j++) printf("%5u", (arr + idx)->record[j]);
		//printf("\n");
	}

	qsort(arr, numRecords, sizeof(rec_t), myComp);

	for (idx = 0; idx < numRecords; ++idx){
		int rc = write(fd2, arr + idx, sizeof(rec_t));
		if (rc != sizeof(rec_t)) {
			errorExit();
		}
	}

	(void) close(fd1);
	(void) close(fd2);
	return 0;
}


